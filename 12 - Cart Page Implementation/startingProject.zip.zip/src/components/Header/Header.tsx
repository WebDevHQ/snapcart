import { Badge, Container, Nav, Navbar } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import { useCartContext } from "../../context/CartContext";
import clsx from "clsx";

const Header = () => {
  const { state } = useCartContext();

  const noOfItemsInCart = state.items.reduce((acc, item) => acc + item.quantity, 0);
  return (
    <Navbar expand="lg" variant="dark" bg="dark">
      <Container>
        <Navbar.Brand as={NavLink} to={"/"}>
          ShopCart
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-shopcart-nav" />
        <Navbar.Collapse id="basic-shopcart-nav">
          <Nav className="me-auto">
            <NavLink className="nav-link" to={"/"}>
              Home
            </NavLink>
            <NavLink className={clsx("nav-link", "position-relative")} to={"/cart"}>
              Cart
              {noOfItemsInCart > 0 ? (
                <Badge pill bg="danger" className="position-absolute start-100 translate-middle">
                  {noOfItemsInCart}
                </Badge>
              ) : null}
            </NavLink>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Header;
