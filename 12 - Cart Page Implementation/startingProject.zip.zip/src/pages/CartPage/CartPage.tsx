import { useEffect } from "react";
import { APP_NAME } from "../../constants/app-constants";
import { useCartContext } from "../../context/CartContext";
import { Button, Col, Container, Row } from "react-bootstrap";
import ProductTile from "../../components/ProductTile/ProductTile";

const CartPage = () => {
  const { state } = useCartContext();

  const total = state.items.reduce((acc, item) => acc + item.price * item.quantity, 0);

  useEffect(() => {
    document.title = `${APP_NAME} - Cart`;
  }, []);

  return (
    <Container>
      <h2>Your Cart</h2>
      {state.items.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <Row className="my-4">
            {state.items.map((item) => (
              <Col key={item.id} sm={12} md={6} xl={3}>
                <ProductTile isTileInCartPage product={item} />
              </Col>
            ))}
          </Row>
          <h3 className="my-4">Total: ${total.toFixed(2)}</h3>
          <Button variant="success">Checkout</Button>
        </>
      )}
    </Container>
  );
};

export default CartPage;
