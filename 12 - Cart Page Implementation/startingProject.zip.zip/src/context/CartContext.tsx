import { createContext, FC, ReactElement, useContext, useEffect, useReducer } from "react";
import { CartAction, cartReducer, CartState, initialState } from "../reducers/cartReducer";

export const CartContext = createContext<{ state: CartState; dispatch: React.Dispatch<CartAction> } | undefined>(
  undefined
);

export const CartContextProvider: FC<{ children: ReactElement }> = ({ children }) => {
  const [state, dispatch] = useReducer(cartReducer, initialState);

  useEffect(() => {
    console.log("State was updated", state);
  }, [state]);

  return <CartContext.Provider value={{ state, dispatch }}>{children}</CartContext.Provider>;
};

export const useCartContext = () => {
  const context = useContext(CartContext);

  if (!context) {
    throw new Error("To use Cart Context, please wrap the application in CartContextProvider");
  }

  return context;
};
