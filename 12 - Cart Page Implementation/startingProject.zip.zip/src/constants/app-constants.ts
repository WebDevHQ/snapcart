export const APP_NAME = "SnapCart";
