import { Container } from "react-bootstrap";

const Footer = () => {
  return (
    <footer className="bg-dark text-white py-3 mt-auto">
      <Container className="text-center">
        <small>&copy; 2024 ShopCart. All rights reserved.</small>
      </Container>
    </footer>
  );
};

export default Footer;
