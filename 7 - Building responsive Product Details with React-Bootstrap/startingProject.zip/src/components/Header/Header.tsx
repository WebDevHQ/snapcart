import { Container, Nav, Navbar } from "react-bootstrap";
import { NavLink } from "react-router-dom";

const Header = () => {
  return (
    <Navbar expand="lg" variant="dark" bg="dark">
      <Container>
        <Navbar.Brand as={NavLink} to={"/"}>
          ShopCart
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-shopcart-nav" />
        <Navbar.Collapse id="basic-shopcart-nav">
          <Nav className="me-auto">
            <NavLink className="nav-link" to={"/"}>
              Home
            </NavLink>
            <NavLink className="nav-link" to={"/cart"}>
              Cart
            </NavLink>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Header;
