import { Button } from "react-bootstrap";
import { useLocation, useNavigate } from "react-router-dom";

const CartPage = () => {
  const navigate = useNavigate();
  const location = useLocation();

  console.log("location", location);

  const handleRouteNavigate = () => {
    navigate("/product/404");
  };

  return (
    <>
      <h1>Cart Page</h1>
      <Button onClick={handleRouteNavigate}>Navigate to 404 product</Button>
    </>
  );
};

export default CartPage;
