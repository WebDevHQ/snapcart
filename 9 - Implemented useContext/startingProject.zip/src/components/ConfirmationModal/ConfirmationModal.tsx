const ConfirmationModal = () => {
  return <div>ConfirmationModal</div>;
};

export default ConfirmationModal;
