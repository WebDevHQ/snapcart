import { Product } from "../models/Product";

const BASE_URL = "https://fakestoreapi.com";

// fetch the list of all products
export const getProducts = async (): Promise<Product[]> => {
  const response = await fetch(`${BASE_URL}/products`);
  return response.json();
};

// fetch the product by id
export const getProductById = async (id: number): Promise<Product> => {
  const response = await fetch(`${BASE_URL}/products/${id}`);
  return response.json();
};
