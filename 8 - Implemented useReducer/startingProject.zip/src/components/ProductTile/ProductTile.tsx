import { FC } from "react";
import { Product } from "../../models/Product";
import { Button, Card } from "react-bootstrap";
import { Link } from "react-router-dom";
import { Cart } from "react-bootstrap-icons";
import { CartAction } from "../../reducers/cartReducer";

interface ProductTileProps {
  product: Product;
  dispatch: React.Dispatch<CartAction>;
}

const ProductTile: FC<ProductTileProps> = ({ product, dispatch }) => {
  const handleAddToCart = () => {
    dispatch({ type: "ADD_TO_CART", payload: { ...product, quantity: 1 } });
  };
  return (
    <Card className="h-100">
      <Card.Img
        variant="top"
        className="mt-3"
        style={{ height: "250px", objectFit: "contain" }}
        src={product.image}
      />
      <Card.Body className="d-flex flex-column">
        <Card.Title>{product.title}</Card.Title>
        <Card.Text className="mt-auto">${product.price}</Card.Text>

        <div className="d-flex flex-column mt-2">
          <Link to={`/product/${product.id}`} className="w-100">
            <Button variant="primary" className="w-100">
              View Details
            </Button>
          </Link>
          <Button
            variant="success"
            className="mt-3 w-100"
            onClick={handleAddToCart}
          >
            <Cart /> Add to Cart
          </Button>
        </div>
      </Card.Body>
    </Card>
  );
};

export default ProductTile;
