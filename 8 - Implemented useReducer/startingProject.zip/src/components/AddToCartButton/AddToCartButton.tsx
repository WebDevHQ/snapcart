const AddToCartButton = () => {
  return <div>AddToCartButton</div>;
};

export default AddToCartButton;
