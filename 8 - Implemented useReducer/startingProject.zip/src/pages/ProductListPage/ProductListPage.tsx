import { useEffect, useReducer, useState } from "react";
import { getProducts } from "../../api/fakestoreAPI";
import { Product } from "../../models/Product";
import ProductTile from "../../components/ProductTile/ProductTile";
import { Col, Container, Row } from "react-bootstrap";
import { cartReducer, initialState } from "../../reducers/cartReducer";

const ProductListPage = () => {
  const [products, setProducts] = useState<Product[]>([]);

  const [state, dispatch] = useReducer(cartReducer, initialState);

  useEffect(() => {
    console.log("State was updated", state);
  }, [state]);

  useEffect(() => {
    getProducts().then(setProducts);
  }, []);
  return (
    <Container>
      <Row className="gy-4">
        {products.map((product) => (
          <Col key={product.id} xl={3} lg={4} sm={6} xs={12}>
            <ProductTile dispatch={dispatch} product={product} />
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default ProductListPage;
