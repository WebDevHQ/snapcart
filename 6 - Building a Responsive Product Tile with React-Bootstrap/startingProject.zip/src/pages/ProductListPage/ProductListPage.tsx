import { useEffect, useState } from "react";
import { getProducts } from "../../api/fakestoreAPI";
import { Product } from "../../models/Product";
import ProductTile from "../../components/ProductTile/ProductTile";
import { Col, Container, Row } from "react-bootstrap";

const ProductListPage = () => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    getProducts().then(setProducts);
  }, []);
  return (
    <Container>
      <Row className="gy-4">
        {products.map((product) => (
          <Col key={product.id} xl={3} lg={4} sm={6} xs={12}>
            <ProductTile product={product} />
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default ProductListPage;
