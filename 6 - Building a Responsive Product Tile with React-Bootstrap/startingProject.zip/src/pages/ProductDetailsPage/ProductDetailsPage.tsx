const ProductDetailsPage = () => {
  return <div>ProductDetailsPage</div>;
};

export default ProductDetailsPage;
