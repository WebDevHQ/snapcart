import { FC } from "react";
import { CartItem } from "../../models/Product";
import { Badge, Button } from "react-bootstrap";
import { Cart } from "react-bootstrap-icons";

interface AddToCartButtonProps {
  addToCart: () => void;
  productInstanceInCart?: CartItem;
}

const AddToCartButton: FC<AddToCartButtonProps> = ({ addToCart, productInstanceInCart }) => {
  return (
    <div className="position-relative mt-3">
      <Button variant={productInstanceInCart ? "secondary" : "success"} className="w-100" onClick={addToCart}>
        <Cart /> {productInstanceInCart ? "Item in Cart" : "Add to Cart"}
      </Button>
      {productInstanceInCart ? (
        <Badge pill bg="danger" className="position-absolute start-100 translate-middle">
          {productInstanceInCart.quantity}
        </Badge>
      ) : null}
    </div>
  );
};

export default AddToCartButton;
