import axios, { AxiosError, AxiosResponse, InternalAxiosRequestConfig } from "axios";
import { Product } from "../models/Product";

// new interface for handling message in ApiErrorResponse
interface ApiErrorResponse {
  message?: string;
}

const apiClient = axios.create({
  baseURL: "https://fakestoreapi.com",
  timeout: 10000,
});

// request interceptor for logging
apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  console.log("Request:", {
    url: config.url,
    method: config.method,
    headers: config.headers,
    data: config.data,
  });

  return config;
});

// response interceptor for logging
apiClient.interceptors.response.use(
  (response: AxiosResponse) => {
    console.log("Response:", {
      url: response.config.url,
      status: response.status,
      data: response.data,
    });

    return response;
  },
  (error: AxiosError) => {
    console.error("Error Response:", {
      url: error.config?.url,
      status: error.response?.status,
      data: error.response?.data,
    });

    return Promise.reject(error);
  }
);

// error handler
const handleApiError = (error: AxiosError<ApiErrorResponse>): never => {
  const message = error.response?.data?.message || error.message || "Unknown error occurred";
  console.error("API Error:", message);
  throw new Error(message);
};

// Fetch all products
export const getProducts = async (): Promise<Product[]> => {
  try {
    const response = await apiClient.get<Product[]>("/products");
    return response.data;
  } catch (error) {
    handleApiError(error as AxiosError<ApiErrorResponse>);
    throw error;
  }
};

// fetch product by id
export const getProductById = async (id: number): Promise<Product> => {
  try {
    const response = await apiClient.get<Product>(`/products/${id}`);
    return response.data;
  } catch (error) {
    handleApiError(error as AxiosError<ApiErrorResponse>);
    throw error;
  }
};
