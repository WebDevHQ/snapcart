import { Product } from "../models/Product";

const BASE_URL = "https://fakestoreapi.com";

// request and response logging
const customFetch = async (url: string, options?: RequestInit) => {
  console.log("Request:", {
    url,
    method: options?.method || "GET",
    headers: options?.headers,
    body: options?.body,
  });

  const response = await fetch(url, options);

  console.log("Response:", {
    url,
    status: response.status,
    headers: response.headers,
  });

  return response;
};

// error handler
const handleResponse = async (response: Response) => {
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`HTTP Error: ${response.status} - ${error || "Unknown Error"}`);
  }

  return response.json();
};

// fetch the list of all products
export const getProducts = async (): Promise<Product[]> => {
  try {
    const response = await customFetch(`${BASE_URL}/products`);
    return await handleResponse(response);
  } catch (error) {
    console.error("Failed to fetch products:", error);
    throw new Error("Failed to fetch products. Please try again later.");
  }
};

// fetch the product by id
export const getProductById = async (id: number): Promise<Product> => {
  try {
    const response = await customFetch(`${BASE_URL}/products/${id}`);
    return response.json();
  } catch (error) {
    console.error(`Failed to fetch product with id ${id}:`, error);
    throw new Error(`Failed to fetch product with id ${id}. Please try again later.`);
  }
};
