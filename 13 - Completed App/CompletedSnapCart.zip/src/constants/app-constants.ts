export const APP_NAME = "SnapCart";
export const CART_STORAGE_KEY = "shopping_cart";
