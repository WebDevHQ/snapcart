import { CART_STORAGE_KEY } from "../constants/app-constants";
import { CartItem } from "../models/Product";

export interface CartState {
  items: CartItem[];
}

export type CartAction =
  | { type: "ADD_TO_CART"; payload: CartItem }
  | { type: "REMOVE_FROM_CART"; payload: number }
  | {
      type: "UPDATE_QUANTITY";
      payload: { productId: number; quantity: number };
    };

// load from storage
const loadCartFromStorage = (): CartItem[] => {
  try {
    const storedCartItems = sessionStorage.getItem(CART_STORAGE_KEY);
    return storedCartItems ? (JSON.parse(storedCartItems) as CartItem[]) : [];
  } catch (error) {
    console.error("Error loading cart from storage", error);
    return [];
  }
};

// save to storage
const saveCartToStorage = (items: CartItem[]) => {
  try {
    sessionStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
  } catch (error) {
    console.error("Error saving cart to storage", error);
  }
};

export const initialState: CartState = { items: loadCartFromStorage() };

export function cartReducer(state: CartState = initialState, action: CartAction): CartState {
  let updatedCartData: CartItem[] = [];
  switch (action.type) {
    case "ADD_TO_CART": {
      const existingItem = state.items.find((item) => item.id === action.payload.id);
      if (existingItem) {
        updatedCartData = state.items.map((item) =>
          item.id === action.payload.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      } else {
        updatedCartData = [...state.items, action.payload];
      }
      break;
    }
    case "REMOVE_FROM_CART": {
      updatedCartData = state.items.filter((item) => item.id !== action.payload);
      break;
    }
    case "UPDATE_QUANTITY": {
      updatedCartData = state.items.map((item) =>
        item.id === action.payload.productId ? { ...item, quantity: action.payload.quantity } : item
      );
      break;
    }
    default:
      return state;
  }

  saveCartToStorage(updatedCartData);
  return { ...state, items: updatedCartData };
}
