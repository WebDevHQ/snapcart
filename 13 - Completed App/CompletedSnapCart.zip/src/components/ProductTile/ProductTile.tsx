import { FC } from "react";
import { CartItem, Product } from "../../models/Product";
import { Button, Card, Dropdown } from "react-bootstrap";
import { Link } from "react-router-dom";
import { useCartContext } from "../../context/CartContext";
import AddToCartButton from "../AddToCartButton/AddToCartButton";
import { CartDash } from "react-bootstrap-icons";

interface ProductTileProps {
  product: Product | CartItem;
  isTileInCartPage?: boolean;
}

const ProductTile: FC<ProductTileProps> = ({ product, isTileInCartPage = false }) => {
  const { state, dispatch } = useCartContext();

  const productInstanceFromCart = state.items.find((item) => item.id === product.id);

  const handleAddToCart = () => {
    dispatch({
      type: "ADD_TO_CART",
      payload: { ...product, quantity: 1 },
    });
  };

  const removeFromCart = (message?: string) => {
    const confirmed = window.confirm(message ?? "Are you sure you want to remove product from cart?");

    if (confirmed) {
      dispatch({ type: "REMOVE_FROM_CART", payload: product.id });
    }
  };

  const handleQuantityChange = (qty: number) => {
    if (qty === 0) {
      removeFromCart("Setting quantity to zero will remove the product from cart. Proceed?");
    } else {
      dispatch({ type: "UPDATE_QUANTITY", payload: { productId: product.id, quantity: qty } });
    }
  };

  return (
    <Card className="h-100">
      <Card.Img variant="top" className="mt-3" style={{ height: "250px", objectFit: "contain" }} src={product.image} />
      <Card.Body className="d-flex flex-column">
        <Card.Title>{product.title}</Card.Title>
        <Card.Text as="div" className="mt-auto">
          {isTileInCartPage && "quantity" in product ? (
            <div className="d-flex align-items-center justify-content-between my-3">
              <span>
                ${product.price}x{product.quantity}=<strong>${product.price * product.quantity}</strong>
              </span>
              <Dropdown className="ms-3">
                <Dropdown.Toggle variant="dark" size="sm" id="quantityDropdown">
                  Qty: {product?.quantity}
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  {[...Array(11).keys()].map((qty) => (
                    <Dropdown.Item key={qty} onClick={() => handleQuantityChange(qty)}>
                      {qty}
                    </Dropdown.Item>
                  ))}
                </Dropdown.Menu>
              </Dropdown>
            </div>
          ) : (
            `$${product.price}`
          )}
        </Card.Text>

        <div className="d-flex flex-column mt-2">
          <Link to={`/product/${product.id}`} className="w-100">
            <Button variant="primary" className="w-100">
              View Details
            </Button>
          </Link>
          {isTileInCartPage ? (
            <Button variant="warning" onClick={() => removeFromCart()} className="mt-3">
              <CartDash /> Remove from Cart
            </Button>
          ) : (
            <AddToCartButton addToCart={handleAddToCart} productInstanceInCart={productInstanceFromCart} />
          )}
        </div>
      </Card.Body>
    </Card>
  );
};

export default ProductTile;
