import AppRoutes from "./routes/AppRoutes";
import { CartContextProvider } from "./context/CartContext";

const App = () => {
  return (
    <CartContextProvider>
      <AppRoutes />
    </CartContextProvider>
  );
};

export default App;
