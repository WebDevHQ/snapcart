import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Product } from "../../models/Product";
import { getProductById } from "../../api/fakestoreAxiosAPI";
import { Button, Col, Container, Image, Row } from "react-bootstrap";
import { Cart } from "react-bootstrap-icons";
import { APP_NAME } from "../../constants/app-constants";

const ProductDetailsPage = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);

  useEffect(() => {
    if (id) {
      getProductById(parseInt(id)).then(setProduct);
    }
  }, [id]);

  useEffect(() => {
    document.title = `${APP_NAME} - ${product?.title} Details`;
  }, [product]);

  return (
    <Container>
      {product && (
        <Row>
          <Col md={2} className="offset-md-2">
            <Image src={product.image} alt={product.title} fluid style={{ height: "250px", objectFit: "contain" }} />
          </Col>
          <Col md={6}>
            <h2>{product.title}</h2>
            <p>{product.description}</p>
            <h3>${product.price}</h3>

            <Row>
              <Col md="6">
                <Button variant="success" className="mt-3 w-100">
                  <Cart /> Add to Cart
                </Button>
              </Col>
            </Row>
          </Col>
        </Row>
      )}
    </Container>
  );
};

export default ProductDetailsPage;
