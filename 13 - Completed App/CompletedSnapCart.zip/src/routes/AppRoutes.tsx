import { BrowserRouter, Routes, Route } from "react-router-dom";
import ProductListPage from "../pages/ProductListPage/ProductListPage";
import ProductDetailsPage from "../pages/ProductDetailsPage/ProductDetailsPage";
import CartPage from "../pages/CartPage/CartPage";
import { Container } from "react-bootstrap";
import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";

const AppRoutes = () => {
  return (
    <BrowserRouter>
      <div className="d-flex flex-column min-vh-100">
        <Header />
        <Container className="py-4">
          <Routes>
            <Route path="/" Component={ProductListPage} />
            <Route path="/product/:id" Component={ProductDetailsPage} />
            <Route path="/cart" Component={CartPage} />
          </Routes>
        </Container>
        <Footer />
      </div>
    </BrowserRouter>
  );
};

export default AppRoutes;
